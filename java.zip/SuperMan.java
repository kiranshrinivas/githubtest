import java.util.Iterator;

public class SuperMan {
	
	static int redStar(Object[][][] ar, double[] ref){
		
		for (int i = 0; i < ar.length; i++) {
			double sum = 0;
			for (int j = 0; j < ar[i].length; j++) {
				double d = (double) ar[i][j][0];
				int d1 =(int) ar[i][j][1];
				sum = sum + d/d1;
			}
			if(sum >= ref[0] && sum <= ref[1])
				return 1;
		}
		
				return -1;
	}
	
	public static void main(String[] args) {
		Object[][][] ar = new Object[][][]{{{0.433,200}},{{0.89,400},{0.6,300}}};
		double[] ref = new double[]{0.003,0.005};
		
		System.out.println(redStar(ar,ref));
	}

}
