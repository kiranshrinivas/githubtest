
public class MultiDimension {
	
	static void transpose(int[][] a,int[] ar){
		for(int i = 0; i < a.length; i++) {
			if(ar[0]==0 && ar[1]==1) {
				for (int j = 0; j < a[i].length; j++) {
					System.out.print(a[i][j]);
				}
				System.out.println();
			}else if(ar[0]==1 && ar[1]==0){
				for (int j = 0; j < a[i].length; j++) {
					System.out.print(a[j][i]);
				}
				System.out.println();
			}
		}
	}
	
	public static void main(String[] args) {
		int[][] a = new int[][] {{1,2},{3,4}};
		int[] ar = new int[] {1,0};
		
		transpose(a,ar);
	}

}
