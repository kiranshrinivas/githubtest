
public class Groot {
	
	static void findPies(int[] ar,int k) {
		for (int i = 0; i < ar.length; i++) {
			for (int j = 0; j < ar.length-i; j++) {
				int sum = 0;
				for (int j2 = j; j2 <= i+j; j2++) {
					sum += ar[j2];
				}
				if(sum==k) {
					for (int j2 = j; j2 <= i+j; j2++) {
						System.out.print(j2);
					}
					return;
				}
			}
		}
	}
	
	public static void main(String[] args) {
		int[] ar = new int[] {8,4,3,2,6,5};
		int k = 6;
		
		findPies(ar,k);
	}

}
