
public class ArkhamCity {
	
	static int findNumOfStepsRequired(int x,int y) {
		return x*y;
	}
	
	public static void main(String[] args) {
		int x = 3;
		int y = 10;
		
		System.out.println(findNumOfStepsRequired(x,y));
	}

}
