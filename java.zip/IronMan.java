
public class IronMan {
	
	static void findTheRange(int[][] ar,int a) {
		int[] ref = new int[a];
		for (int i = 0; i < ar.length; i++) {
			for (int j = ar[i][0]; j < ar[i][1]; j++) {
				ref[j] += ar[i][2];
			}
		}
		for (int i = 0; i < ref.length; i++) {
			int r = ref[i];
			if(r!=0)
				System.out.print(r+" ");
		}
	}
	
	public static void main(String[] args) {
		int a = 5;
		int[][] ar = new int[][] {{2,4,5},{1,3,6},{2,4,7}};
		
		findTheRange(ar,a);
	}

}
